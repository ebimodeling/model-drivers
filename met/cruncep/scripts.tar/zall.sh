#!/bin/bash
#PBS -N compress all.nc
#PBS -j oe
#PBS -S /bin/bash
#PBS -d /home/groups/ebimodeling/met/cruncep/
#PBS -m abe
#PBS -e henryb@hush.com


module load gsl hdf5 netcdf nco

#ncks --no_tmp_fl -A -C -h -v  qair  qairp.nc  all.nc

ncks --no_tmp_fl -L 4 vars2/all.nc vars2/allz.nc
